import pandas as pd
import joblib


def create_df():
    cols = ['age', 'bp', 'sg', 'al', 'su', 'rbc', 'pc', 'pcc',
            'ba', 'bgr', 'bu', 'sc', 'sod', 'pot', 'hemo', 'pcv', 'wc', 'rc', 'htn', 'dm', 'cad', 'appet', 'pe', 'ane']
    return pd.DataFrame(columns=cols, index=[0])


def fix_missing(df, na_dict):
    df.replace(na_dict, inplace=True)


def load_scaler():
    return joblib.load(r'E:\kidney project\Chronic-Kidney-Diseases-Prediction_CRT\ckd-web-app_CRT\scaler\min-max.pkl')


def load_model():
    return joblib.load(r'E:\kidney project\Chronic-Kidney-Diseases-Prediction_CRT\ckd-web-app_CRT\model\rf-ckd.pkl')
