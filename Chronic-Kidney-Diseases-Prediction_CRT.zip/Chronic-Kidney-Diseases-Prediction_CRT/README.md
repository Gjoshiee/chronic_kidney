# Chronic-Kidney-Diseases-Pridiction
We have used a Machine learning approch for predicting if a patient has CKD. This project involves different ML algorithms such as Decesion trees, Random Forest, Logestic Regression, Support Vector Classifier, Naive Bayes, SGD classifier and KNN. Our accuracy is above 96% in all the models including 100% in 3 of them.
For checking out the comparisions btw different models, goto Project folder.
For checking out the web app, goto ckd-web-app folder.
